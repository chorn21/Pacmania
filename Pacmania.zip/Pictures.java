
public class Pictures {

	public String imageFile;
	public int x, y;
	
	public Pictures(int a, int b, String file) {
		x = a;
		y = b;
		imageFile = file;
	}
	
	public void paint(int x, int y, String imageFile) {
		
	}
}
