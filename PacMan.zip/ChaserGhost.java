
/** ChaserGhost class for PacMan game
 * 
 * @author fry4, horn5
 *
 */

public class ChaserGhost extends Ghost {
	
	public ChaserGhost(int x, int y, String image){
		super(x, y, image); 
		edible = false;
	}
	
	// Moves toward PacMan
	public void move(PacMan pac) {
		if(pac.getX() > x) 
			x+=5;
		else
			x-=5;
		if(pac.getY() > y)
			y+=5;
		else
			y-=5;
	}
	
	// Draws chaser ghosts; overrides the 'paintGhosts' method in the Ghost class
	public static void paintGhosts(ChaserGhost[] chasers) {
		for(int i = 0; i < chasers.length; i++)
			if(chasers[i] != null) chasers[i].paint();
	}
	
	// Moves chaser ghosts; overrides the 'moveGhosts' method in the Ghost class
	public static void moveGhosts(ChaserGhost[] chasers, PacMan pac, int lowerX, int upperX, int lowerY, int upperY) {
		for(int i = 0; i < chasers.length; i++) {
			if(chasers[i] != null) {
				if(chasers[i].isEdible()) chasers[i].edibleMove(pac, lowerX, upperX, lowerY, upperY);
				else chasers[i].move(pac);
			}
		}
	}

	// Toggles edible
	public void toggleEdible(int i) {
		if(edible) imageFile = i == 0 ? "ghost_blinky.png" : "ghost_clyde.png";
		else imageFile = "ghost_edible.png";
		edible = !edible;
	}
}
